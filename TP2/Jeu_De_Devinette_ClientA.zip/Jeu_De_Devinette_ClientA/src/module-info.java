module JeuDeDevinette {
    requires javafx.fxml;
    requires javafx.controls;

    opens sample;
}